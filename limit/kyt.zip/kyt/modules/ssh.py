from kyt import *

#DELETESSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Nombre de Usuario que se Eliminará:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | bot-delssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Usuario** `{user}` **No Encontrado**")
		else:
			await event.respond(f"**Borrado Exitosamente** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Usuario:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Contraseña:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Escoge Dias de Expiración**",buttons=[
[Button.inline(" 7 Dias ","7"),
Button.inline(" 15 Dias ","15")],
[Button.inline(" 30 Dias ","30"),
Button.inline(" 60 Dias ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
       🐾🕊️ SSH OVPN ACCOUNT 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
Username         : `{user.strip()}`
Password         : `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━━━◇
Host             : `{DOMAIN}`
Host Slowdns     : `{HOST}`
Pub Key          : `{PUB}`
Port OpenSSH     : 443, 80, 22
Port Dropbear    : 443, 109
Port SSH WS      : 80, 8080, 8280, 8880
Port SSH UDP     : 1-65535
Port SSH SSL WS  : 443
Port SSL/TLS     : 443
Port OVPN WS SSL : 443
Port OVPN SSL    : 443
Port OVPN TCP    : 443, 1194
Port OVPN UDP    : 2200
BadVPN UDP       : 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━━━◇
SSH WS           : {DOMAIN}:80@{user.strip()}:{pw.strip()}
SSH WS 2         : {DOMAIN}:8080@{user.strip()}:{pw.strip()}
SSH WS 3         : {DOMAIN}:8280@{user.strip()}:{pw.strip()}
SSH WS 4         : {DOMAIN}:8880@{user.strip()}:{pw.strip()}
SSH SSL          : {DOMAIN}:443@{user.strip()}:{pw.strip()}
SSH UDP          : {DOMAIN}:1-65535@{user.strip()}:{pw.strip()}
◇━━━━━━━━━━━━━━━━━━━◇
Payload WSS       : GET wss://google.com/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]
◇━━━━━━━━━━━━━━━━━━━◇
Payload SSH WS    : GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: Websocket[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf][crlf]
◇━━━━━━━━━━━━━━━━━━━◇
Payload ENHANCED  : PATCH / HTTP/1.1[crlf]Host: [host][crlf]Host: ISI_BUG_DISINI[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]
◇━━━━━━━━━━━━━━━━━━━◇
OVPN Download     : https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━━━◇
Save Link Account : https://{DOMAIN}:81/ssh-{user.strip()}.txt
◇━━━━━━━━━━━━━━━━━━━◇
Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Todos los Usuarios SSH
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
""",buttons=[[Button.inline("‹ Regresar Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)



@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Escoge Minutos de Expiración**",buttons=[
[Button.inline(" 10 Minutos ","10"),
Button.inline(" 15 Minutos ","15")],
[Button.inline(" 30 Minutos ","30"),
Button.inline(" 60 Minutos ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		user = "Temporal"+str(random.randint(100,1000))
		pw = "ByJerry"
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
       🐾🕊️ SSH OVPN ACCOUNT 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
Username         : `{user.strip()}`
Password         : `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━━━◇
Host             : `{DOMAIN}`
Host Slowdns     : `{HOST}`
Pub Key          : `{PUB}`
Port OpenSSH     : 443, 80, 22
Port Dropbear    : 443, 109
Port SSH WS      : 80, 8080, 8280, 8880
Port SSH UDP     : 1-65535
Port SSH SSL WS  : 443
Port SSL/TLS     : 443
Port OVPN WS SSL : 443
Port OVPN SSL    : 443
Port OVPN TCP    : 443, 1194
Port OVPN UDP    : 2200
BadVPN UDP       : 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━━━◇
SSH WS           : {DOMAIN}:80@{user.strip()}:{pw.strip()}
SSH WS 2         : {DOMAIN}:8080@{user.strip()}:{pw.strip()}
SSH WS 3         : {DOMAIN}:8280@{user.strip()}:{pw.strip()}
SSH WS 4         : {DOMAIN}:8880@{user.strip()}:{pw.strip()}
SSH SSL          : {DOMAIN}:443@{user.strip()}:{pw.strip()}
SSH UDP          : {DOMAIN}:1-65535@{user.strip()}:{pw.strip()}
◇━━━━━━━━━━━━━━━━━━━◇
Payload WSS       : GET wss://google.com/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]
◇━━━━━━━━━━━━━━━━━━━◇
Payload SSH WS    : GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: Websocket[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf][crlf]
◇━━━━━━━━━━━━━━━━━━━◇
Payload ENHANCED  : PATCH / HTTP/1.1[crlf]Host: [host][crlf]Host: ISI_BUG_DISINI[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]
◇━━━━━━━━━━━━━━━━━━━◇
OVPN Download     : https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━━━◇
Save Link Account : https://{DOMAIN}:81/ssh-{user.strip()}.txt
◇━━━━━━━━━━━━━━━━━━━◇
Expira En     : `{exp} Minutos`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Usuarios Registrados SSH Ovpn
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
""",buttons=[[Button.inline("‹ Regresar ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)


@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" TRIAL SSH ","trial-ssh"),
Button.inline(" CREAR SSH ","create-ssh")],
[Button.inline(" BORRAR SSH ","delete-ssh"),
Button.inline(" CHECK Login SSH ","login-ssh")],
[Button.inline(" MOSTRAR USUARIOS SSH ","show-ssh"),
Button.inline(" REGIS IP ","regis")],
[Button.inline("‹ REGRESAR ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━
**🐾🕊️ SSH OVPN MANAGER 🕊️🐾
━━━━━━━━━━━━━━━━━━━
**🔰 » Service: `SSH OVPN`
**🔰 » Hostname/IP: `{DOMAIN}`
**🔰 » ISP: `{z["isp"]}`
**🔰 » Country: `{z["country"]}`
━━━━━━━━━━━━━━━━━━━
**Creador By Jerry™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
